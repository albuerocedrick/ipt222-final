<?php 
 session_start();
 
require_once __DIR__ . '/controllers/UserController.php';
require_once __DIR__ . '/controllers/ProjectController.php';
require_once __DIR__ . '/controllers/TaskController.php';
require_once __DIR__ . '/controllers/NotificationController.php';
require_once __DIR__ . '/controllers/TaskSubmissionController.php';
require_once __DIR__ . '/controllers/UserTaskStatusController.php';
?>  